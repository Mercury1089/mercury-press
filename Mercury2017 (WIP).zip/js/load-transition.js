window.onload = function() {
   $("body.home").addClass("loaded"); 
};